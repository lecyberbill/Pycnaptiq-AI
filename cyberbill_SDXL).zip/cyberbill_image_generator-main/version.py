def version():
    version = "🖼️ Beta 0.1 🖼️"
    return version
