def version():
    version = " Beta 1.7.3 🐥Chick🐥"
    return version
def version_date():
    version_date = "01 avril 2025"
    return version_date