def version():
    version = " Beta 1.8.6 🐥Crazy Happy Chick🐥"
    return version
def version_date():
    version_date = "05 mai 2025"
    return version_date