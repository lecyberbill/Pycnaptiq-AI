def version():
    version = " Beta 1.8.5 🐥Crazy Happy Chick🐥"
    return version
def version_date():
    version_date = "02 mai 2025"
    return version_date