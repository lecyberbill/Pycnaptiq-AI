def version():
    version = "🖼️ Beta 1.0 🖼️"
    return version
