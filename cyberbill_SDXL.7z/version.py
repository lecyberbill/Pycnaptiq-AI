def version():
    version = " Beta 1.5 🖼️"
    return version
