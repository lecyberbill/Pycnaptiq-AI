# civitai_browser_mod.py
import os
import json
from Utils.utils import txt_color, translate, GestionModule  # Import GestionModule

# Obtenir le chemin du fichier JSON du module
module_json_path = os.path.join(os.path.dirname(__file__), "civitai_browser_mod.json")

# Créer une instance de GestionModule pour gérer les dépendances
with open(module_json_path, 'r', encoding="utf-8") as f:
    module_data = json.load(f)
module_manager = GestionModule(translations=module_data["language"]["fr"])

# Maintenant, on peut faire les imports en toute sécurité
import gradio as gr
import requests
from tqdm import tqdm
import pandas as pd
from PIL import Image
import io
import numpy as np


def initialize(global_translations, global_pipe=None, global_compel=None, global_config=None):
    """Initialise le module Civitai Browser."""
    print(txt_color("[OK] ", "ok"), module_data["name"])
    return CivitaiBrowser(global_translations, global_pipe, global_compel, global_config)


class CivitaiBrowser:
    def __init__(self, global_translations, global_pipe=None, global_compel=None, global_config=None):
        self.current_page = 1  # Variable pour suivre la page actuelle
        self.global_translations = global_translations
        self.global_pipe = None
        self.global_compel = None 
        self.global_config = None

    def create_tab(self, module_translations):
        """Crée l'onglet Gradio pour le navigateur Civitai."""
        with gr.Tab(translate("civitai_browser", module_translations)) as tab:
            gr.Markdown(f"## {translate('civitai_browser_title', module_translations)}")
            with gr.Row():
                with gr.Column(scale=1):
                    page_display = gr.Textbox(
                        label=translate("current_page", module_translations), 
                        interactive=False, 
                        value="Page 1"
                    )
                    prev_button = gr.Button("⬅️ Précédent")
                    next_button = gr.Button("Suivant ➡️")
                with gr.Column(scale=4):
                    with gr.Accordion(translate("advanced_search", module_translations), open=True):
                        limit = gr.Slider(
                            label=translate("limit", module_translations),
                            value=10,
                            step=1,
                            minimum=1,
                            maximum=200
                        )
                        nsfw = gr.Dropdown(
                            choices=["Soft", "Mature", "X", "All"],
                            value="Soft",
                            label=translate("nsfw", module_translations)
                        )
                        sort = gr.Dropdown(
                            choices=["Most Reactions", "Most Comments", "Newest", "Oldest"],
                            value="Newest",
                            label=translate("sort", module_translations)
                        )
                        period = gr.Dropdown(
                            choices=["All Time", "Year", "Month", "Week", "Day"],
                            value="Day",
                            label=translate("period", module_translations)
                        )
                    # Bouton pour lancer la recherche avec les paramètres avancés
                    refresh_button = gr.Button("Charger")
                    # Affichage de la galerie sous forme de HTML (grille)
            image_gallery = gr.HTML()


            refresh_button.click(
                self.search_civitai,
                inputs=[limit, nsfw, sort, period],
                outputs=[image_gallery, page_display],
                
            )

            prev_button.click(
                self.previous_page,
                inputs=[limit, nsfw, sort, period],
                outputs=[image_gallery, page_display]
            )

            next_button.click(
                self.next_page,
                inputs=[limit, nsfw, sort, period],
                outputs=[image_gallery, page_display]
            )
            

        return tab

    def search_civitai(self, limit, nsfw, sort, period):
        """Effectue une recherche et affiche les résultats sur la première page."""
        self.current_page = 1  # Réinitialisation à la première page
        return self.fetch_images(limit, nsfw, sort, period, self.current_page)

    def previous_page(self, limit, nsfw, sort, period):
        """Passe à la page précédente si possible."""
        if self.current_page > 1:
            self.current_page -= 1
        return self.fetch_images(limit, nsfw, sort, period, self.current_page)

    def next_page(self, limit, nsfw, sort, period):
        """Passe à la page suivante."""
        self.current_page += 1
        return self.fetch_images(limit, nsfw, sort, period, self.current_page)

    def get_js_functions(self):
        """Returns the JavaScript functions as a string."""
        js_code = """
        () => {
            // --- Fonctions Utilitaires (locales) ---
            function toggleMeta(id) {
                // Vérifie si l'ID est fourni
                if (!id) {
                    console.error("toggleMeta appelé sans ID");
                    return;
                }
                const meta = document.getElementById(id);
                if (meta) {
                    // Ajoute ou retire la classe 'active' pour afficher/masquer
                    meta.classList.toggle("active");
                } else {
                    // Avertit si l'élément overlay n'est pas trouvé
                    console.error("Élément overlay non trouvé pour l'ID:", id);
                }
            }

            function copyToClipboard(textId) {
                // Vérifie si l'ID est fourni
                if (!textId) {
                    console.error("copyToClipboard appelé sans ID");
                    return;
                }
                const textElement = document.getElementById(textId);
                if (textElement) {
                    const text = textElement.innerText;
                    // Utilise l'API Clipboard (nécessite contexte sécurisé: https/localhost)
                    navigator.clipboard.writeText(text).then(() => {
                        alert("Prompt copié !"); // Confirmation pour l'utilisateur
                    }).catch(err => {
                        // Gestion d'erreur si la copie échoue
                        console.error("Erreur lors de la copie dans le presse-papiers:", err);
                        alert("Erreur lors de la copie.");
                    });
                } else {
                    // Avertit si l'élément contenant le texte n'est pas trouvé
                    console.error("Élément texte non trouvé pour l'ID:", textId);
                }
            }

            // --- Délégation d'Événements ---
            // Ajoute un seul écouteur sur un parent stable (body)
            console.log("Initialisation des écouteurs d'événements JS pour la galerie Gradio...");
            document.body.addEventListener('click', function(event) {
                // Trouve le bouton le plus proche correspondant aux sélecteurs
                const metaButton = event.target.closest('.meta-button');
                const closeButton = event.target.closest('.close-btn');
                const copyButton = event.target.closest('.copy-btn');

                // Agit en fonction du bouton cliqué
                if (metaButton) {
                    // Récupère l'ID de l'overlay depuis l'attribut data-*
                    const overlayId = metaButton.getAttribute('data-overlay-id');
                    toggleMeta(overlayId);
                } else if (closeButton) {
                    // Récupère l'ID de l'overlay depuis l'attribut data-*
                    const overlayId = closeButton.getAttribute('data-overlay-id');
                    toggleMeta(overlayId); // Le bouton fermer utilise la même fonction
                } else if (copyButton) {
                    // Récupère l'ID du texte à copier depuis l'attribut data-*
                    const textId = copyButton.getAttribute('data-text-id');
                    copyToClipboard(textId);
                }
            });
            console.log("Écouteurs d'événements JS prêts.");

        }
        """
        return js_code

    def get_module_js(self):
        """Return the javascript code for the module"""
        return self.get_js_functions()

    def fetch_images(self, limit, nsfw, sort, period, page):
        base_url = "https://civitai.com/api/v1/images"
        params = {
            "limit": int(limit),
            "page": int(page),
            "nsfw": nsfw,
            "sort": sort,
            "period": period
        }

        try:
            response = requests.get(base_url, params=params)
            response.raise_for_status()
            data = response.json()
            images = data.get("items", [])

            html_gallery = """
            <style>
            /* Conteneur principal pour la grille et le défilement */
            .gallery-container {
                max-height: 80vh; /* Hauteur maximale du conteneur */
                overflow-y: auto; /* Active le défilement vertical */
                margin-top: 20px; /* Marge au-dessus de la grille */
                padding-right: 10px; /* Espace pour la scrollbar */
            }
            /* Grille d'images */
            .image-grid {
                display: grid;
                grid-template-columns: repeat(auto-fill, minmax(240px, 1fr));
                gap: 20px;
                margin-top: 20px;
            }
            /* Conteneur de la carte avec hauteur fixe */
            .image-container {
                position: relative;
                height: 350px;
                border: 1px solid #ddd;
                border-radius: 8px;
                overflow: hidden;
                background: #000;
                display: flex;
                flex-direction: column;
                justify-content: space-between;
            }
            /* L'image occupe la partie supérieure, s'ouvre dans un nouvel onglet */
            .image-container a {
                display: block;
                height: 70%;
            }
            .image_card {
                width: 100%;
                height: 100%;
                object-fit: cover;
                cursor: pointer;
            }
            /* Bouton "Voir métadonnées" stylé */
            .meta-button {
                background: white;
                color: black;
                border: 1px solid #ccc;
                border-radius: 8px;
                padding: 8px;
                width: 100%;
                cursor: pointer;
                font-weight: bold;
                margin-top: 4px;
            }
            .meta-button:hover {
                background: #000;
            }
            /* Overlay pour les métadonnées, couvrant toute la carte */
            .overlay {
                position: absolute;
                top: 0;
                left: 0;
                width: 100%;
                height: 100%;
                background: rgba(0,0,0,0.8);
                color: #fff;
                display: none; /* Conservé - pour le toggle JS */
                flex-direction: column;
                /* Changé/Supprimé: justify-content et align-items pour permettre le scroll depuis le haut */
                justify-content: flex-start; /* Aligne le contenu en haut */
                align-items: center; /* Garde le centrage horizontal */
                padding: 20px; /* Conserve le padding */
                /* Ajouté: Espace pour le bouton fermer en haut peut être géré par le padding ou la position du contenu */
                padding-top: 50px; /* Augmente le padding haut pour laisser de la place au bouton fermer */
                box-sizing: border-box;
                z-index: 10;
            }
            .overlay.active {
                display: flex;
            }
            .overlay .close-btn {
                position: absolute;
                top: 10px;
                right: 10px;
                background: none;
                border: none;
                font-size: 20px;
                color: #fff;
                cursor: pointer;
            }
            .meta-content {
                text-align: left;
                width: 90%; /* Limite la largeur (ou 100  pour cent i vous préférez utiliser tout l'espace horizontal) */
                max-width: 100%; /* Assurez-vous qu'il ne dépasse pas le parent */
            /* margin-top: 30px; */ /* Peut être retiré si padding-top sur .overlay gère l'espacement */
                margin-bottom: 20px; /* Ajoute un peu d'espace en bas */

                /* --- C'est la partie clé pour le scrolling --- */
                max-height: calc(100% - 20px); /* Hauteur max = 100 pour cent la hauteur restante - marge basse */
                        /* Ajustez ce calcul si nécessaire (ex: 100% - 40px si vous avez du padding bas aussi) */
                        /* Ou une valeur fixe: max-height: 250px; */
                overflow-y: auto; /* Affiche la barre de défilement verticale si besoin */
                /* --- Fin de la partie clé --- */

                /* Amélioration visuelle pour la barre de scroll (optionnel, dépend du navigateur) */
                scrollbar-width: thin; /* Pour Firefox */
                scrollbar-color: #666 #333; /* Couleur pouce/piste pour Firefox */
            }

            .meta-content::-webkit-scrollbar {
                width: 8px;
            }

            .meta-content::-webkit-scrollbar-track {
                background: #333;
                border-radius: 4px;
            }

            .meta-content::-webkit-scrollbar-thumb {
                background-color: #666;
                border-radius: 4px;
                border: 2px solid #333;
            }

            .overlay .close-btn {
                position: absolute;
                top: 15px; /* Ajusté pour être dans le nouveau padding-top */
                right: 15px;
                background: none;
                border: none;
                font-size: 24px; /* Légèrement plus grand peut-être */
                color: #fff;
                cursor: pointer;
                z-index: 11; /* Au-dessus du contenu scrollable */
            }

            .copy-btn {
                background: #007bff;
                color: white;
                padding: 5px 10px;
                border: none;
                cursor: pointer;
                margin-top: 5px;
                border-radius: 4px;
            }
            .copy-btn:hover {
                background: #0056b3;
            }
            </style>
            <div class="gallery-container">
            <div class="image-grid">
            """

            for i, image in enumerate(images):
                if image is None:
                    continue

                image_url = image.get("url", "")
                meta = image.get("meta") or {}
                prompt = meta.get("prompt", "Aucun prompt")
                negative_prompt = meta.get("negativePrompt", "Aucun negative prompt")
                steps = meta.get("steps", "N/A")
                sampler = meta.get("sampler", "N/A")
                seed = meta.get("seed", "N/A")
                clip_skip = meta.get("Clip skip", "N/A")

                html_gallery += f"""
                <div class="image-container">
                <a href="{image_url}" target="_blank">
                    <img src="{image_url}" class="image_card">
                </a>
                <button class="meta-button" data-overlay-id="overlay-{i}">
                    Voir métadonnées
                </button>
                <div class="overlay" id="overlay-{i}">
                    <button class="close-btn" data-overlay-id="overlay-{i}">✖</button>
                    <div class="meta-content">
                    <h3>Prompt</h3>
                    <p id="prompt-{i}">{prompt}</p>
                    <button class="copy-btn" data-text-id="prompt-{i}">📋 Copier</button>
                    <h3>Negative Prompt</h3>
                    <p>{negative_prompt}</p>
                    <h3>Autres métadonnées</h3>
                    <ul>
                        <li><strong>Steps:</strong> {steps}</li>
                        <li><strong>Sampler:</strong> {sampler}</li>
                        <li><strong>Seed:</strong> {seed}</li>
                        <li><strong>Clip Skip:</strong> {clip_skip}</li>
                    </ul>
                    </div>
                </div>
                </div>
                """

            html_gallery += "</div></div>"
            return html_gallery, f"Page {page}"

        except requests.exceptions.RequestException as e:
            print(text_color("[ERREUR] ", "erreur"), translate("erreur_recherche_civitai", module_translations), f": {e}")
            raise gr.Error(translate("erreur_recherche_civitai", module_translations) + f": {e}", 4.0)
            return "<p>Erreur lors de la recherche.</p>", f"Page {page}"


