def version():
    version = " Beta 1.6.5 🥚 eggs 🥚"
    return version
def version_date():
    version_date = "01 avril 2025"
    return version_date