def version():
    version = "Alpha 0.2"
    return version
