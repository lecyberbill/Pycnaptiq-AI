def version():
    version = "Alpha 0.1"
    return version